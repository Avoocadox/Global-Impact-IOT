EQUIPE - FHG - TECH
TURMA - 2TDSS

INTEGRANTES:

GABRIEL VINICIUS BATISTA	RM 85526
FILLIPI SILVA			RM 84649
HIGOR HOLANDA			RM 86371


How-to:

Utilize a base de dados no mesmo diretório do código fonte e, não altere o nome de referência da base.
O vídeo explica todo o algoritmo e a descrição das funcionalidades e categorizações.



link do vídeo:

https://youtu.be/MERBRcIgcDk