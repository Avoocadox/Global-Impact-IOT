import math
#FORMULA QUE CONTA QUANTIDADE DE DADOS DA ULTIMA COLUNA DO DATASET
def info_dataset(amostras):
    output1,output2 = 0,0
    
    for amostra in amostras:
        if amostra[-1] == 1:
            output1 += 1
        else:
            output2 += 1
    return [len(amostras), output1, output2]
def distancia_euclidiana(p1,p2):
    dimensao = len(p1)
    soma = 0
    for i in range(dimensao):
        soma += (p1[i] - p2[i]) **2
    return math.sqrt(soma)
def knn(treinamento, nova_amostra, k):
    distancias = {}
    tamanho_treino = len(treinamento)
    
    for i in range(tamanho_treino):
        d = distancia_euclidiana(treinamento[i], nova_amostra)
        distancias[i] = d
    k_vizinhos = sorted(distancias, key=distancias.get)[:k]
    
    qtd_output1 = 0
    qtd_output2 = 0
    for indice in k_vizinhos:
        if treinamento[indice][-1] == 1:
            qtd_output1 += 1
        else:
            qtd_output2 += 1
    if qtd_output1 > qtd_output2:
        return 1
    else:
        return 0

amostras = []
with open ('dataset_tomate.csv', 'r') as dataset:
    for linha in dataset.readlines():
        x = linha.replace('\n','').split(',')
        lista_estrutural = []
        for i in range(22):
            lista_estrutural.append(float(x[i]))
        amostras.append(lista_estrutural)
    
porcentagem = 0.7

_, output1, output2 = info_dataset(amostras)
treinamento = []
teste = []

max_output1 = int(porcentagem * output1)
max_output2 = int(porcentagem * output2)

total_output1 = 0
total_output2 = 0

for amostra in amostras:
    if (total_output1 + total_output2) <= (max_output1 + max_output2):
        treinamento.append(amostra)
        if amostra[-1] == 1 and total_output1 < max_output1:
            total_output1 +=1
        else:
            total_output2 +=1
    else:
        teste.append(amostra)
  
acertos = 0
k = 11

for numero_amostra in teste:
    classe = knn(treinamento, numero_amostra,k)
    if amostra[-1] == classe:
        acertos += 1


print("Total de treinamento: " , len(treinamento))
print("Total de testes: " , len(teste))
print("Total de acertos: " , acertos)
print("Porcentagem de acerto: " , 100*acertos/len(teste))